package com.example.hotspot;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * CalendarActivity displays the user's calendar view.
 * Shows a monthly calendar grid and a list of upcoming events.
 * Handles navigation between main app sections.
 */
public class CalendarActivity extends AppCompatActivity {

    // UI Components
    private RecyclerView calendarGrid;
    private RecyclerView recyclerEvents;

    // Database and adapter
    private EventDatabaseHelper dbHelper;
    private EventsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar_page);

        // Initialize database helper
        dbHelper = new EventDatabaseHelper(this);

        // Setup calendar grid (7 columns for days of week)
        calendarGrid = findViewById(R.id.calendarGrid);
        calendarGrid.setLayoutManager(new GridLayoutManager(this, 7));

        // Setup RecyclerView for event list
        recyclerEvents = findViewById(R.id.recyclerEvents);
        recyclerEvents.setLayoutManager(new GridLayoutManager(this, 1));

        // Load events from database
        loadEvents();

        // Setup bottom navigation
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setSelectedItemId(R.id.nav_calendar);

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
                finish();
                return true;
            }

            if (id == R.id.nav_calendar) {
                // Already on Calendar screen
                return true;
            }

            if (id == R.id.nav_alerts) {
                // Check SMS permission before navigating to alerts
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED) {
                    startActivity(new Intent(this, AlertsActivity.class));
                } else {
                    startActivity(new Intent(this, NotificationsActivity.class));
                }
                return true;
            }

            if (id == R.id.nav_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                finish();
                return true;
            }

            return false;
        });
    }

    /**
     * Loads all events from the database and binds them to the RecyclerView.
     */
    private void loadEvents() {
        adapter = new EventsAdapter(this, dbHelper.getAllEvents(), dbHelper);
        recyclerEvents.setAdapter(adapter);
    }
}