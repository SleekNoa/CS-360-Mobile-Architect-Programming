package com.example.hotspot;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;

/**
 * AlertsActivity displays the user's alerts and notifications.
 * Fetches alerts from the database and shows them in a RecyclerView.
 * Includes bottom navigation for app-wide navigation.
 */
public class AlertsActivity extends AppCompatActivity {

    // UI Component
    private RecyclerView rvAlerts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alerts);

        // Initialize RecyclerView
        rvAlerts = findViewById(R.id.rvAlerts);
        rvAlerts.setLayoutManager(new LinearLayoutManager(this));

        // Load alerts from database
        loadAlerts();

        // Setup bottom navigation
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setSelectedItemId(R.id.nav_alerts);

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
                finish();
                return true;
            }

            if (id == R.id.nav_calendar) {
                startActivity(new Intent(this, CalendarActivity.class));
                finish();
                return true;
            }

            if (id == R.id.nav_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                finish();
                return true;
            }

            if (id == R.id.nav_alerts) {
                // Already on Alerts screen
                return true;
            }

            return false;
        });
    }

    /**
     * Loads alerts for the current user from the database
     * and binds them to the RecyclerView using AlertsAdapter.
     */
    private void loadAlerts() {
        EventDatabaseHelper dbHelper = new EventDatabaseHelper(this);

        // Hardcoded user ID = 1 (demo purposes)
        // In a real app, this would come from a logged-in user session
        int currentUserId = 1;

        List<Alert> alerts = dbHelper.getAlertsForUser(currentUserId);

        AlertsAdapter adapter = new AlertsAdapter(alerts);
        rvAlerts.setAdapter(adapter);
    }
}