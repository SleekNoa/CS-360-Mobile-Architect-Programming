package com.example.hotspot;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * EventsAdapter is a RecyclerView adapter responsible for displaying
 * a list of events in a card format. It supports user interactions
 * such as marking interest, going to an event, and deleting events.
 */
public class EventsAdapter extends RecyclerView.Adapter<EventsAdapter.EventViewHolder> {

    // Data source and dependencies
    private final List<Event> events;
    private final Context context;
    private final EventDatabaseHelper dbHelper;

    /**
     * Constructor for the adapter.
     *
     * @param context   The application context
     * @param events    List of Event objects to display
     * @param dbHelper  Database helper for performing CRUD operations
     */
    public EventsAdapter(Context context, List<Event> events, EventDatabaseHelper dbHelper) {
        this.context = context;
        this.events = events;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the event card layout for each item
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_event_card, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        // Get the current event at this position
        Event event = events.get(position);

        // Bind event data to the views
        holder.tvTitle.setText(event.getTitle());
        holder.tvDescription.setText(event.getDescription());
        holder.tvDate.setText(event.getDateTime());
        holder.tvLocation.setText(event.getLocation());

        // Delete button - removes event from database and list
        holder.btnDelete.setOnClickListener(v -> {
            int deleted = dbHelper.deleteEvent(event.getId());
            if (deleted > 0) {
                // Remove from local list and notify RecyclerView
                events.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, events.size());

                Toast.makeText(context, R.string.event_deleted, Toast.LENGTH_SHORT).show();
            }
        });

        // "Going" button - simple feedback
        holder.btnGoing.setOnClickListener(v ->
                Toast.makeText(context, R.string.youre_going, Toast.LENGTH_SHORT).show());

        // "Interested" button - simple feedback
        holder.btnInterested.setOnClickListener(v ->
                Toast.makeText(context, R.string.marked_interested, Toast.LENGTH_SHORT).show());
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    /**
     * ViewHolder class that holds references to all views in a single event card.
     * This improves performance by avoiding repeated findViewById calls.
     */
    static class EventViewHolder extends RecyclerView.ViewHolder {

        // TextViews for event details
        TextView tvTitle, tvDescription, tvDate, tvLocation;

        // Action buttons
        Button btnGoing, btnInterested, btnDelete;

        EventViewHolder(View itemView) {
            super(itemView);

            // Bind views from the layout
            tvTitle = itemView.findViewById(R.id.tvEventTitle);
            tvDescription = itemView.findViewById(R.id.tvEventDescription);
            tvDate = itemView.findViewById(R.id.tvEventDate);
            tvLocation = itemView.findViewById(R.id.tvEventLocation);

            btnGoing = itemView.findViewById(R.id.btnGoing);
            btnInterested = itemView.findViewById(R.id.btnInterested);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}