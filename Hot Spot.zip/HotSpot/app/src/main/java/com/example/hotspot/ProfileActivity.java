package com.example.hotspot;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * ProfileActivity displays the user's profile information.
 * Includes tabs for My Events, Saved Deals, and Following.
 * Also handles bottom navigation between main app sections.
 */
public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Initialize bottom navigation
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);

        // Highlight the current tab (Profile)
        bottomNav.setSelectedItemId(R.id.nav_profile);

        // Set up navigation item selection listener
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                // Navigate to Home screen
                startActivity(new Intent(this, MainActivity.class));
                finish();
                return true;
            }

            if (id == R.id.nav_calendar) {
                // Navigate to Calendar screen
                startActivity(new Intent(this, CalendarActivity.class));
                finish();
                return true;
            }

            if (id == R.id.nav_alerts) {
                // Navigate to Notifications / Alerts flow
                startActivity(new Intent(this, NotificationsActivity.class));
                finish();
                return true;
            }

            if (id == R.id.nav_profile) {
                // Already on Profile screen - do nothing
                return true;
            }

            // Default case
            return false;
        });
    }
}