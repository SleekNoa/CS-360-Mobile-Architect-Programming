package com.example.hotspot;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

/**
 * MainActivity serves as the home screen of the app.
 * Displays a list of events and provides navigation to other sections.
 */
public class MainActivity extends AppCompatActivity {

    // UI Components
    private RecyclerView recyclerViewEvents;
    private EventsAdapter adapter;

    // Database helper
    private EventDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_grid);

        // Initialize database helper
        dbHelper = new EventDatabaseHelper(this);

        // Setup RecyclerView for events
        recyclerViewEvents = findViewById(R.id.recyclerEvents);
        recyclerViewEvents.setLayoutManager(new GridLayoutManager(this, 1));

        // Load initial data
        loadEvents();

        // Setup Floating Action Button for adding new events
        FloatingActionButton fabAdd = findViewById(R.id.fabCreateEvent);
        fabAdd.setOnClickListener(v -> showAddEventDialog());

        // Setup bottom navigation
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setSelectedItemId(R.id.nav_home);
        bottomNav.setOnItemSelectedListener(this::onNavigationItemSelected);
    }

    /**
     * Loads all events from the database and updates the RecyclerView adapter.
     */
    private void loadEvents() {
        List<Event> events = dbHelper.getAllEvents();
        adapter = new EventsAdapter(this, events, dbHelper);
        recyclerViewEvents.setAdapter(adapter);
    }

    /**
     * Displays a dialog for adding a new event.
     * Validates input and saves to database if valid.
     */
    private void showAddEventDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_event, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();

        // Get references to dialog views
        EditText etTitle = dialogView.findViewById(R.id.etEventName);
        EditText etDescription = dialogView.findViewById(R.id.etEventDescription);
        EditText etDate = dialogView.findViewById(R.id.etEventDate);
        EditText etLocation = dialogView.findViewById(R.id.etEventLocation);

        Button btnSave = dialogView.findViewById(R.id.btnSaveEvent);
        Button btnCancel = dialogView.findViewById(R.id.btnCancel);

        btnSave.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String desc = etDescription.getText().toString().trim();
            String date = etDate.getText().toString().trim();
            String location = etLocation.getText().toString().trim();

            // Required field validation
            if (title.isEmpty()) {
                Toast.makeText(this, R.string.error_event_title_required, Toast.LENGTH_SHORT).show();
                return;
            }

            // Save event to database (use defaults for empty fields)
            long newId = dbHelper.addEvent(
                    title,
                    desc.isEmpty() ? "" : desc,
                    date.isEmpty() ? getString(R.string.default_tbd) : date,
                    location.isEmpty() ? getString(R.string.default_tbd) : location
            );

            if (newId != -1) {
                loadEvents(); // Refresh the list
                Toast.makeText(this, R.string.new_event_added, Toast.LENGTH_SHORT).show();
            }

            dialog.dismiss();
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    /**
     * Handles navigation item selection from the bottom navigation bar.
     */
    private boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Already on home screen - do nothing
            return true;
        }

        if (id == R.id.nav_calendar) {
            startActivity(new Intent(this, CalendarActivity.class));
            return true;
        }

        if (id == R.id.nav_alerts) {
            // Check SMS permission before going to alerts
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                startActivity(new Intent(this, AlertsActivity.class));
            } else {
                startActivity(new Intent(this, NotificationsActivity.class));
            }
            return true;
        }

        if (id == R.id.nav_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
            return true;
        }

        return true;
    }
}