package com.example.hotspot;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * EventDatabaseHelper manages the SQLite database for the HotSpot app.
 * Handles three main tables: Users, Events, and Alerts.
 * Provides CRUD operations for all entities.
 */
public class EventDatabaseHelper extends SQLiteOpenHelper {

    // Database configuration
    private static final String DATABASE_NAME = "HotSpot.db";
    private static final int DATABASE_VERSION = 2;

    // ====================== Table Names ======================
    private static final String TABLE_USERS = "users";
    private static final String TABLE_EVENTS = "events";
    private static final String TABLE_ALERTS = "alerts";

    // ====================== Users Table Columns ======================
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // ====================== Events Table Columns ======================
    private static final String COLUMN_EVENT_ID = "id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_DATETIME = "datetime";
    private static final String COLUMN_LOCATION = "location";

    // ====================== Alerts Table Columns ======================
    private static final String COLUMN_ALERT_ID = "id";
    private static final String COLUMN_ALERT_USER_ID = "user_id";
    private static final String COLUMN_ALERT_TITLE = "title";
    private static final String COLUMN_ALERT_MESSAGE = "message";
    private static final String COLUMN_ALERT_TYPE = "type";
    private static final String COLUMN_ALERT_READ = "is_read";

    // ====================== Alert Type Constants ======================
    public static final String ALERT_TYPE_CONNECTION = "connection";
    public static final String ALERT_TYPE_EVENT = "event";
    public static final String ALERT_TYPE_SYSTEM = "system";

    public EventDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        // Enable foreign key constraints for referential integrity
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUsersTable);

        // Create Events Table
        String createEventsTable = "CREATE TABLE " + TABLE_EVENTS + " (" +
                COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TITLE + " TEXT, " +
                COLUMN_DESCRIPTION + " TEXT, " +
                COLUMN_DATETIME + " TEXT, " +
                COLUMN_LOCATION + " TEXT)";
        db.execSQL(createEventsTable);

        // Create Alerts Table with foreign key to Users
        String createAlertsTable = "CREATE TABLE " + TABLE_ALERTS + " (" +
                COLUMN_ALERT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ALERT_USER_ID + " INTEGER, " +
                COLUMN_ALERT_TITLE + " TEXT, " +
                COLUMN_ALERT_MESSAGE + " TEXT, " +
                COLUMN_ALERT_TYPE + " TEXT, " +
                COLUMN_ALERT_READ + " INTEGER DEFAULT 0, " +
                "FOREIGN KEY(" + COLUMN_ALERT_USER_ID + ") REFERENCES " +
                TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(createAlertsTable);

        // Insert sample data for demo purposes
        insertSampleUser(db);
        insertSampleEvents(db);
        insertSampleAlerts(db);
    }

    private void insertSampleUser(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, "Noah");
        values.put(COLUMN_PASSWORD, "password123");
        db.insert(TABLE_USERS, null, values);
    }

    private void insertSampleEvents(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, "Live Music at NewBo");
        values.put(COLUMN_DESCRIPTION, "Live Music at NewBo. Bring Friends and Family!");
        values.put(COLUMN_DATETIME, "Tonight • 8:00 PM");
        values.put(COLUMN_LOCATION, "NewBo Market • 0.8 mi");
        db.insert(TABLE_EVENTS, null, values);
    }

    private void insertSampleAlerts(SQLiteDatabase db) {
        ContentValues values = new ContentValues();

        // Sample Connection Alert
        values.put(COLUMN_ALERT_USER_ID, 1);
        values.put(COLUMN_ALERT_TITLE, "New Connection Request");
        values.put(COLUMN_ALERT_MESSAGE, "Noah wants to connect with you.");
        values.put(COLUMN_ALERT_TYPE, ALERT_TYPE_CONNECTION);
        db.insert(TABLE_ALERTS, null, values);

        values.clear();

        // Sample Event Alert
        values.put(COLUMN_ALERT_USER_ID, 1);
        values.put(COLUMN_ALERT_TITLE, "Event Reminder");
        values.put(COLUMN_ALERT_MESSAGE, "Live Music at NewBo starts in 2 hours.");
        values.put(COLUMN_ALERT_TYPE, ALERT_TYPE_EVENT);
        db.insert(TABLE_ALERTS, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables and recreate with new schema
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ALERTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // ====================== User Methods ======================

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1; // Returns true if insert was successful
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS +
                        " WHERE " + COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password});

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // ====================== Event Methods ======================

    public long addEvent(String title, String desc, String datetime, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_DESCRIPTION, desc);
        values.put(COLUMN_DATETIME, datetime);
        values.put(COLUMN_LOCATION, location);

        return db.insert(TABLE_EVENTS, null, values);
    }

    public List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_EVENTS, null);

        if (cursor.moveToFirst()) {
            do {
                events.add(new Event(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_EVENT_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATETIME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_LOCATION)),
                        null
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return events;
    }

    public int deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_EVENTS, COLUMN_EVENT_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    public int updateEvent(int id, String title, String desc, String datetime, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_DESCRIPTION, desc);
        values.put(COLUMN_DATETIME, datetime);
        values.put(COLUMN_LOCATION, location);

        return db.update(TABLE_EVENTS, values, COLUMN_EVENT_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    // ====================== Alert Methods ======================

    public long addAlert(int userId, String title, String message, String type) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ALERT_USER_ID, userId);
        values.put(COLUMN_ALERT_TITLE, title);
        values.put(COLUMN_ALERT_MESSAGE, message);
        values.put(COLUMN_ALERT_TYPE, type);

        return db.insert(TABLE_ALERTS, null, values);
    }

    public List<Alert> getAlertsForUser(int userId) {
        List<Alert> alerts = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_ALERTS +
                        " WHERE " + COLUMN_ALERT_USER_ID + "=?",
                new String[]{String.valueOf(userId)}
        );

        if (cursor.moveToFirst()) {
            do {
                alerts.add(new Alert(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ALERT_ID)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ALERT_USER_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ALERT_TITLE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ALERT_MESSAGE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ALERT_TYPE)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ALERT_READ)) == 1
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return alerts;
    }

    public int markAlertRead(int alertId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ALERT_READ, 1);

        return db.update(TABLE_ALERTS, values, COLUMN_ALERT_ID + "=?",
                new String[]{String.valueOf(alertId)});
    }

    public int deleteAlert(int alertId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_ALERTS, COLUMN_ALERT_ID + "=?",
                new String[]{String.valueOf(alertId)});
    }

    public int getUnreadAlertCount(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM " + TABLE_ALERTS +
                        " WHERE " + COLUMN_ALERT_USER_ID + "=?" +
                        " AND " + COLUMN_ALERT_READ + "=0",
                new String[]{String.valueOf(userId)}
        );

        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }
}