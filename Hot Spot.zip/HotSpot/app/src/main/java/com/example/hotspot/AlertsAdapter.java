package com.example.hotspot;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * AlertsAdapter is a RecyclerView adapter that displays a list of alerts.
 * Supports different alert types (connection requests, event reminders, etc.)
 * and shows appropriate icons for each type.
 */
public class AlertsAdapter extends RecyclerView.Adapter<AlertsAdapter.AlertViewHolder> {

    // List of alerts to display
    private final List<Alert> alerts;

    /**
     * Constructor for the adapter.
     *
     * @param alerts List of Alert objects to display
     */
    public AlertsAdapter(List<Alert> alerts) {
        this.alerts = alerts;
    }

    @NonNull
    @Override
    public AlertViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the alert card layout for each item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_alert_card, parent, false);

        return new AlertViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AlertViewHolder holder, int position) {
        // Get the current alert
        Alert alert = alerts.get(position);

        // Bind alert data to the views
        holder.tvTitle.setText(alert.getTitle());
        holder.tvMessage.setText(alert.getMessage());

        // Set appropriate icon based on alert type
        if ("connection".equals(alert.getType())) {
            holder.imgAlert.setImageResource(R.drawable.outline_account_box_24);
        } else {
            // Default icon for event and system alerts
            holder.imgAlert.setImageResource(R.drawable.outline_circle_notifications_24);
        }
    }

    @Override
    public int getItemCount() {
        return alerts.size();
    }

    /**
     * ViewHolder class that caches references to views in each alert card.
     * Improves performance by avoiding repeated findViewById() calls.
     */
    static class AlertViewHolder extends RecyclerView.ViewHolder {

        ImageView imgAlert;
        TextView tvTitle;
        TextView tvMessage;

        public AlertViewHolder(@NonNull View itemView) {
            super(itemView);

            // Bind views from the layout
            imgAlert = itemView.findViewById(R.id.imgAlert);
            tvTitle = itemView.findViewById(R.id.tvAlertTitle);
            tvMessage = itemView.findViewById(R.id.tvAlertMessage);
        }
    }
}