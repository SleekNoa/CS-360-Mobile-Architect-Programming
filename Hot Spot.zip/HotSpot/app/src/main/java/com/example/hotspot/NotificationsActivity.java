package com.example.hotspot;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * NotificationsActivity handles SMS permission request for event alerts.
 * Guides the user through granting or denying SMS notifications.
 */
public class NotificationsActivity extends AppCompatActivity {

    // UI Components
    private Button btnRequestSmsPermission;
    private Button btnDenyPermission;
    private TextView tvStatus;

    /**
     * Modern Activity Result API launcher for requesting runtime permissions.
     * Handles the user's response (granted or denied).
     */
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (isGranted) {
                            tvStatus.setText(R.string.status_permission_granted);
                            Toast.makeText(this, R.string.sms_granted, Toast.LENGTH_SHORT).show();

                            // Proceed to Alerts screen after permission granted
                            startActivity(new Intent(NotificationsActivity.this, AlertsActivity.class));
                            finish();
                        } else {
                            tvStatus.setText(R.string.sms_denied);
                            Toast.makeText(this, R.string.sms_denied, Toast.LENGTH_SHORT).show();
                            // App continues without SMS - no finish() here
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        // Initialize views
        btnRequestSmsPermission = findViewById(R.id.btnRequestSmsPermission);
        btnDenyPermission = findViewById(R.id.btnDenyPermission);
        tvStatus = findViewById(R.id.tvStatus);

        // Update UI based on current permission state
        updatePermissionStatus();

        // "Allow SMS Notifications" button
        btnRequestSmsPermission.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                // Request permission
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            } else {
                // Already granted - close screen
                finish();
            }
        });

        // "Not Now" button - closes immediately
        btnDenyPermission.setOnClickListener(v -> finish());
    }

    /**
     * Checks current SMS permission status and updates UI accordingly.
     * Disables the request button if permission is already granted.
     */
    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            tvStatus.setText(R.string.status_permission_granted);
            btnRequestSmsPermission.setEnabled(false);
        } else {
            tvStatus.setText(R.string.status_permission_not_requested);
        }
    }
}