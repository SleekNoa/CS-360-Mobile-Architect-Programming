package com.example.hotspot;

public class Event {
    private int id;
    private String title;
    private String description;
    private String dateTime;
    private String location;
    private String imageUrl;

    public Event(int id, String title, String description, String dateTime, String location, String imageUrl) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.dateTime = dateTime;
        this.location = location;
        this.imageUrl = imageUrl;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getDateTime() { return dateTime; }
    public String getLocation() { return location; }
    public String getImageUrl() { return imageUrl; }
}