package com.example.hotspot;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerViewEvents;
    private EventsAdapter adapter;
    private EventDatabaseHelper dbHelper;
    private static final int SMS_PERMISSION_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_grid);

        dbHelper = new EventDatabaseHelper(this);

        // === IMPORTANT: Update these IDs to match your layout files ===
        recyclerViewEvents = findViewById(R.id.recyclerEvents);
        recyclerViewEvents.setLayoutManager(new GridLayoutManager(this, 1));

        loadEvents();

        FloatingActionButton fabAdd = findViewById(R.id.fabCreateEvent);
        fabAdd.setOnClickListener(v -> showAddEventDialog());

        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(this::onNavigationItemSelected);

        requestSmsPermission();
    }

    private void loadEvents() {
        List<Event> events = dbHelper.getAllEvents();
        adapter = new EventsAdapter(this, events, dbHelper);
        recyclerViewEvents.setAdapter(adapter);
    }

    private void showAddEventDialog() {
        Toast.makeText(this, R.string.add_event, Toast.LENGTH_LONG).show();

        dbHelper.addEvent("New Local Event",
                "Join us for a great time!",
                "Tomorrow 7PM",
                "Downtown Marion");
        loadEvents();
        Toast.makeText(this, R.string.new_event_added, Toast.LENGTH_SHORT).show();
    }

    private boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_alerts) {                    // Using nav_alerts (notification icon)
            startActivity(new Intent(this, NotificationsActivity.class));
            return true;
        }
        // You can add other navigation cases here later
        return true;
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, R.string.sms_granted, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, R.string.sms_, Toast.LENGTH_SHORT).show();
            }
        }
    }
}