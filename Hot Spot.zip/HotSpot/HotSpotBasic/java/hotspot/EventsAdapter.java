package com.example.hotspot;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EventsAdapter extends RecyclerView.Adapter<EventsAdapter.EventViewHolder> {

    private final List<Event> events;
    private final Context context;
    private final EventDatabaseHelper dbHelper;

    public EventsAdapter(Context context, List<Event> events, EventDatabaseHelper dbHelper) {
        this.context = context;
        this.events = events;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_event_card, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = events.get(position);

        holder.tvTitle.setText(event.getTitle());
        holder.tvDescription.setText(event.getDescription());
        holder.tvDate.setText(event.getDateTime());
        holder.tvLocation.setText(event.getLocation());

        holder.btnDelete.setOnClickListener(v -> {
            int deleted = dbHelper.deleteEvent(event.getId());
            if (deleted > 0) {
                events.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, events.size());
                Toast.makeText(context, R.string.event_deleted, Toast.LENGTH_SHORT).show();
            }
        });

        holder.btnGoing.setOnClickListener(v ->
                Toast.makeText(context, R.string.youre_going, Toast.LENGTH_SHORT).show());

        holder.btnInterested.setOnClickListener(v ->
                Toast.makeText(context, R.string.marked_interested, Toast.LENGTH_SHORT).show());
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvDescription, tvDate, tvLocation;
        Button btnGoing, btnInterested, btnDelete;

        EventViewHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvEventTitle);
            tvDescription = itemView.findViewById(R.id.tvEventDescription);
            tvDate = itemView.findViewById(R.id.tvEventDate);           // Make sure this ID exists in item_event_card.xml
            tvLocation = itemView.findViewById(R.id.tvEventLocation);
            btnGoing = itemView.findViewById(R.id.btnGoing);
            btnInterested = itemView.findViewById(R.id.btnInterested);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}